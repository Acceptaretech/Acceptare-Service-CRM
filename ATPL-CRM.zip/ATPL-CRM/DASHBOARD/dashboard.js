document.addEventListener('DOMContentLoaded', function () {

  const submenuParents = document.querySelectorAll('.has-submenu');

  submenuParents.forEach(parent => {
    const title = parent.querySelector('.menu-title');

    title.addEventListener('click', function () {

      submenuParents.forEach(item => {
        if (item !== parent) {
          item.classList.remove('open');
        }
      });

      parent.classList.toggle('open');
    });
  });

  const filterSelect = document.querySelector('.filters select');
  const cardValues = document.querySelectorAll('.card h3');

  const dashboardData = {
    Today: {
      cards: [120, 35, 12, 5],
      sales: [3000, 4200, 2800, 5000],
      status: [8, 3, 1]
    },
    'Last 7 Days': {
      cards: [450, 120, 48, 22],
      sales: [8000, 12000, 10000, 15000],
      status: [30, 12, 6]
    },
    'Last 30 Days': {
      cards: [1250, 320, 185, 64],
      sales: [15000, 22000, 18000, 26000],
      status: [65, 20, 15]
    },
    'This Month': {
      cards: [980, 260, 140, 41],
      sales: [14000, 20000, 17000, 24000],
      status: [52, 18, 10]
    }
  };


  function updateCards(data) {
    cardValues.forEach((card, index) => {
      card.textContent = data.cards[index];
    });
  }

  const salesCtx = document.getElementById('salesChart').getContext('2d');
  const statusCtx = document.getElementById('statusChart').getContext('2d');

  const salesChart = new Chart(salesCtx, {
    type: 'line',
    data: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      datasets: [{
        data: dashboardData['Last 30 Days'].sales,
        borderColor: '#2563eb',
        backgroundColor: 'rgba(37, 99, 235, 0.15)',
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      }
    }
  });

  const statusChart = new Chart(statusCtx, {
    type: 'doughnut',
    data: {
      labels: ['Won', 'Pending', 'Lost'],
      datasets: [{
        data: dashboardData['Last 30 Days'].status,
        backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '70%',
      plugins: {
        legend: {
          position: 'right'
        }
      }
    }
  });



  filterSelect.addEventListener('change', function () {
    const selectedRange = this.value;
    const data = dashboardData[selectedRange];

    if (!data) return;

    updateCards(data);

    salesChart.data.datasets[0].data = data.sales;
    salesChart.update();

    statusChart.data.datasets[0].data = data.status;
    statusChart.update();
  });

});

const toggle = document.querySelector('.menu-toggle');
const sidebar = document.querySelector('.sidebar');

toggle.addEventListener('click', () => {
  sidebar.classList.toggle('open');
});
